Legacy Tkinter implementation, retained for reference. Paths are relative to goi2. Not needed by Flutter.
