"""Real Tk smoke test. Run from goi2 with desktop display access."""
import sys,time,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
import tkinter as tk
from unittest.mock import patch
from types import SimpleNamespace
from PIL import ImageGrab,Image
import numpy as np
from frequency_filter.gui import FilterApp
from frequency_filter.filters import partner

root=tk.Tk();app=FilterApp(root)
base=Path(__file__).resolve().parents[2]
errors=[]

def pump():
    root.update_idletasks();root.update()

def finish():
    deadline=time.monotonic()+20
    while app.busy:
        pump();time.sleep(.02)
        if time.monotonic()>deadline:raise AssertionError('Worker timeout')
    pump()

with tempfile.TemporaryDirectory() as temp,patch('frequency_filter.gui.messagebox.showerror',side_effect=lambda *a,**k:errors.append(a)):
    # Cancellation leaves the starting state untouched.
    with patch('frequency_filter.gui.filedialog.askopenfilename',return_value=''):app.open_image()
    assert app.image is None
    # Open file through the same callback as the button.
    app.variables['padding'].set('Không padding')
    path=base/'results/demo/noisy.png'
    with patch('frequency_filter.gui.filedialog.askopenfilename',return_value=str(path)):app.open_image()
    finish();assert not errors,errors
    assert not app.dirty
    np.testing.assert_allclose(app.result.output,app.image,atol=1e-10)
    app.variables['filter'].set('Mask thủ công');pump()
    assert str(app.save_button['state'])=='disabled'
    event=SimpleNamespace(inaxes=app.axes[1,0],button=1,xdata=53.,ydata=47.)
    app.on_click(event);assert len(app.actions)==1
    app.preview();finish()
    h=app.result.transfer
    assert h[47,53]==0 and h[81,75]==0
    np.testing.assert_array_equal(h,partner(h))
    with patch('frequency_filter.gui.filedialog.asksaveasfilename',return_value=''):app.save()
    saved=Path(temp)/'ảnh kết quả.png'
    with patch('frequency_filter.gui.filedialog.asksaveasfilename',return_value=str(saved)):app.save()
    with Image.open(saved) as im:assert im.size==(128,128)
    out=Path(temp)/'bộ kết quả'
    out.mkdir()
    with patch('frequency_filter.gui.filedialog.askdirectory',return_value=str(out)):app.export()
    assert (out/'config.json').exists()
    # Refusal must leave existing files unchanged.
    (out/'config.json').write_text('KEEP')
    with patch('frequency_filter.gui.filedialog.askdirectory',return_value=str(out)),patch('frequency_filter.gui.messagebox.askyesno',return_value=False):app.export()
    assert (out/'config.json').read_text()=='KEEP'
    app.undo();assert not app.actions and app.dirty
    app.on_click(event);app.preview();finish()
    root.lift();pump();time.sleep(.3);pump()
    x,y=root.winfo_rootx(),root.winfo_rooty()
    ImageGrab.grab(bbox=(x,y,x+root.winfo_width(),y+root.winfo_height())).save(base/'docs/gui/giao_dien_mask.png')
    # New image with changed dimensions must reset prior mask and cached spectrum.
    path2=Path(temp)/'ảnh mới.png';Image.fromarray(np.full((15,23),100,dtype=np.uint8)).save(path2)
    app.variables['padding'].set('Gương')
    with patch('frequency_filter.gui.filedialog.askopenfilename',return_value=str(path2)):app.open_image()
    finish();assert not app.actions and app.result.output.shape==(15,23)
    # Stale worker completion cannot enable saving for edited parameters.
    app.preview();app.variables['radius'].set('4');finish()
    assert app.dirty and str(app.save_button['state'])=='disabled'
    for mode in ['Bandpass','Khử sọc — Suppress Stripes','Notch tự dò','Bandpass theo ImageJ']:
        app.variables['filter'].set(mode);app.preview();finish();assert not errors,errors
        assert not app.dirty
    app.variables['width'].set('0');app.variables['filter'].set('Bandpass');app.preview();finish()
    assert errors and app.dirty and str(app.save_button['state'])=='disabled'
    # Automatic mode at minimum window size: parameter pane remains scrollable.
    app.variables['filter'].set('Notch tự dò');root.geometry('1050x700');pump();time.sleep(.4);pump()
    ImageGrab.grab(bbox=(root.winfo_rootx(),root.winfo_rooty(),root.winfo_rootx()+root.winfo_width(),root.winfo_rooty()+root.winfo_height())).save(base/'docs/gui/giao_dien_tham_so.png')
app.close()
print('Desktop smoke passed: open/cancel, preview, paired mask, undo, save/export/cancel, overwrite refusal, new image, stale worker, all filters and errors.')
