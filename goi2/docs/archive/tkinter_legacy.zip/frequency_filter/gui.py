"""Desktop entry point: python -m frequency_filter.gui"""
from pathlib import Path
import queue
import threading
import tkinter as tk
from tkinter import font as tkfont
from tkinter import ttk, filedialog, messagebox
import numpy as np
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from .gui_model import read_image, process, manual_transfer, save_image, export_bundle
from .pipeline import power_spectrum

FILTERS = {'Không lọc — FFT/IFFT':'identity', 'Bandpass':'bandpass',
           'Khử sọc — Suppress Stripes':'stripes', 'Mask thủ công':'mask',
           'Notch tự dò':'auto', 'Bandpass theo ImageJ':'imagej'}
PADDING = {'Gương':'symmetric', 'Chèn số 0':'zero', 'Lặp biên':'edge',
           'Không padding':'none', 'Gương theo ImageJ':'imagej'}
FIELDS = {
 'center':('Tâm dải (bin)','20'), 'width':('Độ rộng dải (bin)','10'),
 'order':('Bậc Butterworth','4'), 'radius':('Bán kính notch / mask','3'),
 'tolerance':('Tolerance (%)','5'), 'protect':('Bảo vệ tâm (bin)','0'),
 'exclude':('Bỏ vùng tâm (bin)','10'), 'threshold':('Ngưỡng dò (k × MAD)','6'),
 'max_pairs':('Số cặp đỉnh tối đa','12'), 'large':('Cấu trúc lớn (pixel)','40'),
 'small':('Cấu trúc nhỏ (pixel)','3')}
VISIBLE = {'identity':[], 'bandpass':['kind','center','width','order'],
 'stripes':['direction','tolerance','protect'], 'mask':['mask_mode','radius'],
 'auto':['kind','radius','order','exclude','threshold','max_pairs'], 'imagej':['large','small']}


class FilterApp:
    def __init__(self, root):
        self.root = root
        families={f.lower():f for f in tkfont.families(root)}
        self.font_family=next((families[f] for f in ('dejavu sans','noto sans','arial','helvetica') if f in families), 'TkDefaultFont')
        for name in ('TkDefaultFont','TkTextFont','TkMenuFont','TkHeadingFont','TkCaptionFont'):
            tkfont.nametofont(name).configure(family=self.font_family,size=11)
        root.title('Nhóm 14 · Lọc ảnh mức xám trong miền tần số')
        root.geometry('1360x850'); root.minsize(1050,700)
        self.image = None; self.path = None; self.result = None
        self.actions = []; self.busy = False; self.dirty = True
        self.revision = 0; self.closed = False; self.messages = queue.Queue()
        self.result_source = None; self.suppress_changes = False
        self.variables = {key:tk.StringVar(value=default) for key,(_,default) in FIELDS.items()}
        self.variables.update(filter=tk.StringVar(value='Không lọc — FFT/IFFT'),
          padding=tk.StringVar(value='Gương'),backend=tk.StringVar(value='radix2'),
          kind=tk.StringVar(value='Gaussian'),direction=tk.StringVar(value='Ngang'),
          mask_mode=tk.StringVar(value='Chặn vùng chọn'))
        self.status = tk.StringVar(value='Bấm Mở ảnh… để bắt đầu.')
        self.info = tk.StringVar(value='Chưa mở ảnh')
        self._build()
        for key,var in self.variables.items():
            var.trace_add('write', lambda *_, k=key:self.changed(k))
        self.update_fields()
        self.root.protocol('WM_DELETE_WINDOW', self.close)
        self.root.after(100,self.poll)

    def _build(self):
        style = ttk.Style(self.root)
        if 'clam' in style.theme_names(): style.theme_use('clam')
        style.configure('TButton',padding=(10,7))
        style.configure('Title.TLabel',font=(self.font_family,15,'bold'))
        shell=ttk.Frame(self.root,padding=12);shell.pack(fill='both',expand=True)
        top=ttk.Frame(shell);top.pack(fill='x',pady=(0,10))
        ttk.Label(top,text='Lọc ảnh · Miền tần số',style='Title.TLabel').pack(side='left',padx=(0,24))
        self.open_button=ttk.Button(top,text='Mở ảnh…',command=self.open_image);self.open_button.pack(side='left',padx=4)
        self.preview_button=ttk.Button(top,text='Xem trước',command=self.preview);self.preview_button.pack(side='left',padx=4)
        self.save_button=ttk.Button(top,text='Lưu ảnh…',command=self.save);self.save_button.pack(side='left',padx=4)
        self.export_button=ttk.Button(top,text='Xuất bộ kết quả…',command=self.export);self.export_button.pack(side='left',padx=4)
        main=ttk.Frame(shell);main.pack(fill='both',expand=True)
        side_shell=ttk.Frame(main);side_shell.pack(side='left',fill='y',padx=(0,10))
        scroller=tk.Canvas(side_shell,width=270,highlightthickness=0)
        scroll=ttk.Scrollbar(side_shell,orient='vertical',command=scroller.yview)
        scroll.pack(side='right',fill='y');scroller.pack(side='left',fill='y')
        scroller.configure(yscrollcommand=scroll.set)
        side=ttk.Frame(scroller,padding=(0,0,10,0))
        window=scroller.create_window((0,0),window=side,anchor='nw')
        side.bind('<Configure>',lambda e:scroller.configure(scrollregion=scroller.bbox('all')))
        scroller.bind('<Configure>',lambda e:scroller.itemconfigure(window,width=e.width))
        ttk.Label(side,textvariable=self.info,wraplength=255).pack(fill='x',pady=(0,14))
        for key,label,choices in [('filter','Bộ lọc',list(FILTERS)),('padding','Padding',list(PADDING)),
                                  ('backend','FFT', ['radix2','numpy'])]:
            ttk.Label(side,text=label).pack(anchor='w',pady=(8,3))
            combo=ttk.Combobox(side,textvariable=self.variables[key],values=choices,state='readonly')
            combo.pack(fill='x')
            if key=='padding': self.padding_combo=combo
        self.params=ttk.LabelFrame(side,text='Tham số',padding=10);self.params.pack(fill='x',pady=14)
        self.field_frames={}
        combo_fields={'kind':('Dạng bộ lọc',['Ideal','Gaussian','Butterworth']),
          'direction':('Hướng sọc',['Ngang','Dọc']),
          'mask_mode':('Thao tác mask',['Chặn vùng chọn','Giữ vùng chọn'])}
        for key in list(combo_fields)+list(FIELDS):
            frame=ttk.Frame(self.params);self.field_frames[key]=frame
            label=combo_fields[key][0] if key in combo_fields else FIELDS[key][0]
            ttk.Label(frame,text=label).pack(anchor='w')
            if key in combo_fields:
                ttk.Combobox(frame,textvariable=self.variables[key],values=combo_fields[key][1],state='readonly').pack(fill='x',pady=(3,7))
            else:
                ttk.Entry(frame,textvariable=self.variables[key]).pack(fill='x',pady=(3,7))
        self.mask_tools=ttk.Frame(side)
        ttk.Button(self.mask_tools,text='Hoàn tác vùng cuối',command=self.undo).pack(fill='x',pady=2)
        ttk.Button(self.mask_tools,text='Xóa toàn bộ mask',command=self.clear_mask).pack(fill='x',pady=2)
        self.hint=ttk.Label(side,wraplength=255,foreground='#35556d');self.hint.pack(fill='x',pady=10)
        plot=ttk.Frame(main);plot.pack(side='left',fill='both',expand=True)
        self.figure=Figure(figsize=(9,7),dpi=100,facecolor='#f4f7fb')
        self.axes=self.figure.subplots(2,2)
        self.figure.subplots_adjust(left=.04,right=.98,bottom=.04,top=.95,hspace=.20,wspace=.13)
        self.canvas=FigureCanvasTkAgg(self.figure,master=plot)
        self.canvas.get_tk_widget().pack(fill='both',expand=True)
        self.toolbar=NavigationToolbar2Tk(self.canvas,plot,pack_toolbar=False);self.toolbar.pack(fill='x')
        self.canvas.mpl_connect('button_press_event',self.on_click)
        footer=ttk.Frame(shell);footer.pack(side='bottom',before=main,fill='x',pady=(8,0))
        self.progress=ttk.Progressbar(footer,mode='indeterminate',length=110);self.progress.pack(side='right')
        ttk.Label(footer,textvariable=self.status,wraplength=1000).pack(side='left')
        self.draw();self.update_buttons()

    def mode(self): return FILTERS[self.variables['filter'].get()]

    def update_fields(self):
        mode=self.mode()
        for frame in self.field_frames.values():frame.pack_forget()
        for key in VISIBLE[mode]:self.field_frames[key].pack(fill='x')
        self.mask_tools.pack_forget()
        if mode=='mask':self.mask_tools.pack(fill='x')
        self.padding_combo.configure(state='disabled' if mode=='imagej' else 'readonly')
        hints={'mask':'Click trái trên phổ để thêm vùng và vùng đối xứng. Bấm Xem trước để cập nhật ảnh. Dùng Hoàn tác nếu chọn nhầm.',
          'auto':'Đỉnh mạnh cũng có thể là chi tiết thật. Kiểm tra các dấu + trên phổ trước khi lưu.',
          'bandpass':'Bandpass loại DC: kết quả có thể tối. Preview và file lưu cùng thang sáng 0–255.',
          'imagej':'Tự dùng padding gương theo ImageJ. Chưa đối chiếu số liệu trực tiếp với Fiji.',
          'identity':'Không lọc: kiểm tra ảnh khôi phục bằng FFT và IFFT.',
          'stripes':'Chọn hướng của sọc nhìn thấy trên ảnh gốc.'}
        self.hint.configure(text=hints[mode])

    def changed(self,key):
        if self.suppress_changes:return
        self.revision+=1;self.dirty=True
        if key in ('padding','backend','mask_mode'):self.actions=[]
        self.update_fields();self.update_buttons()
        if self.image is not None:
            self.status.set('Tham số đã đổi — bấm Xem trước để cập nhật trước khi lưu.')
            self.draw()

    def settings(self):
        values={}
        for key in VISIBLE[self.mode()]:
            if key in FIELDS:
                number=float(self.variables[key].get())
                if not np.isfinite(number):raise ValueError('Tham số phải là số hữu hạn.')
                if key in ('order','max_pairs'):
                    if number != int(number):raise ValueError('Bậc và số cặp đỉnh phải là số nguyên.')
                    number=int(number)
                values[key]=number
        # Defaults for fields not used in this mode are not parsed.
        for key,(_,default) in FIELDS.items():values.setdefault(key,float(default))
        values.update(filter=self.mode(),padding='imagej' if self.mode()=='imagej' else PADDING[self.variables['padding'].get()],
          backend=self.variables['backend'].get(),kind=self.variables['kind'].get().lower(),
          direction='horizontal' if self.variables['direction'].get()=='Ngang' else 'vertical',
          mask_mode='reject' if self.variables['mask_mode'].get()=='Chặn vùng chọn' else 'pass',
          source_path=str(self.path))
        return values

    def open_image(self):
        if self.busy:return
        path=filedialog.askopenfilename(parent=self.root,title='Chọn ảnh từ máy',filetypes=[('Ảnh','*.png *.jpg *.jpeg *.bmp *.tif *.tiff'),('Tất cả','*')])
        if not path:return
        try:image,mode=read_image(path)
        except Exception as exc:
            messagebox.showerror('Không mở được ảnh',str(exc),parent=self.root);return
        self.image=image;self.path=Path(path);self.result=None;self.result_source=None;self.actions=[]
        self.revision+=1;self.dirty=True
        self.info.set(f'{self.path.name}\n{image.shape[1]} × {image.shape[0]} pixel\n'+('Đã chuyển sang ảnh xám 8-bit' if mode!='L' else 'Ảnh xám 8-bit'))
        self.draw();self.preview()

    def preview(self):
        if self.busy or self.image is None:return
        try:settings=self.settings()
        except (ValueError,tk.TclError) as exc:
            messagebox.showerror('Tham số chưa hợp lệ',str(exc),parent=self.root);return
        cached=None
        if self.result is not None and self.result_source is self.image:
            p=self.result.prepared
            if p.padding==settings['padding'] and p.backend==settings['backend']:cached=p
        source=self.image;actions=tuple(self.actions);revision=self.revision
        self.busy=True;self.progress.start(12);self.update_buttons()
        self.status.set('Đang tính phổ và lọc ảnh…')
        def worker():
            try:payload=process(source,settings,actions,cached);error=None
            except Exception as exc:payload=None;error=exc
            self.messages.put((revision,source,payload,error))
        threading.Thread(target=worker,daemon=True).start()

    def poll(self):
        if self.closed:return
        try:
            revision,source,result,error=self.messages.get_nowait()
        except queue.Empty:pass
        else:
            self.busy=False;self.progress.stop()
            if revision != self.revision:
                self.status.set('Tham số đã đổi trong lúc xử lý — bấm Xem trước để cập nhật.')
            elif error is not None:
                self.dirty=True;self.status.set('Chưa xử lý được. Kiểm tra tham số hoặc padding.')
                messagebox.showerror('Không xử lý được ảnh',str(error),parent=self.root)
            else:
                self.result=result;self.result_source=source;self.dirty=False
                self.status.set(f'Đã cập nhật · {result.seconds:.3f} giây · Phổ {result.prepared.spectrum.shape[1]} × {result.prepared.spectrum.shape[0]}' +
                  (f' · Dò được {len(result.peaks)} cặp đỉnh' if self.mode()=='auto' else ''))
            self.update_buttons();self.draw()
        self.root.after(100,self.poll)

    def update_buttons(self):
        self.open_button.configure(state='disabled' if self.busy else 'normal')
        self.preview_button.configure(state='normal' if self.image is not None and not self.busy else 'disabled')
        state='normal' if self.result is not None and not self.dirty and not self.busy else 'disabled'
        self.save_button.configure(state=state);self.export_button.configure(state=state)

    def usable_spectrum(self):
        if self.result is None or self.result_source is not self.image:return False
        expected='imagej' if self.mode()=='imagej' else PADDING[self.variables['padding'].get()]
        return self.result.prepared.padding==expected and self.result.prepared.backend==self.variables['backend'].get()

    def draw(self):
        titles=['Ảnh gốc · xám 8-bit','Ảnh sau lọc' + (' · chưa cập nhật' if self.dirty else ''),
                'Phổ Fourier · log power','Mask / hàm truyền H']
        for ax,title in zip(self.axes.flat,titles):ax.clear();ax.set_title(title,fontsize=11);ax.axis('off')
        if self.image is not None:self.axes[0,0].imshow(self.image,cmap='gray',vmin=0,vmax=255)
        if self.result is not None:
            self.axes[0,1].imshow(self.result.output,cmap='gray',vmin=0,vmax=255)
        if self.usable_spectrum():
            p=self.result.prepared;s=np.log1p(power_spectrum(p.spectrum))
            self.axes[1,0].imshow(s,cmap='gray')
            h=self.result.transfer
            if self.mode()=='mask':
                mode='reject' if self.variables['mask_mode'].get()=='Chặn vùng chọn' else 'pass'
                h=manual_transfer(s.shape,self.actions,mode)
                for row,col,radius in self.actions:
                    from matplotlib.patches import Circle
                    for r,c in [(row,col),((2*(s.shape[0]//2)-row)%s.shape[0],(2*(s.shape[1]//2)-col)%s.shape[1])]:
                        self.axes[1,0].add_patch(Circle((c,r),radius,fill=False,edgecolor='#00c8d7',linewidth=1.5))
            elif not self.dirty:
                for u,v in self.result.peaks:
                    for sign in (-1,1):
                        self.axes[1,0].plot((s.shape[1]//2+sign*v)%s.shape[1],(s.shape[0]//2+sign*u)%s.shape[0],'+',color='#ffb52e')
            self.axes[1,1].imshow(h,cmap='gray',vmin=0,vmax=1)
        self.canvas.draw_idle()

    def on_click(self,event):
        if self.busy or self.mode()!='mask' or event.inaxes is not self.axes[1,0] or event.button!=1:return
        if self.toolbar.mode:return
        if not self.usable_spectrum():
            self.status.set('Bấm Xem trước để tạo phổ đúng với padding hiện tại.');return
        if event.xdata is None or event.ydata is None:return
        try:
            radius=float(self.variables['radius'].get())
            if not np.isfinite(radius) or radius<=0:raise ValueError('Bán kính phải lớn hơn 0.')
        except ValueError as exc:
            messagebox.showerror('Bán kính chưa hợp lệ',str(exc),parent=self.root);return
        self.actions.append((round(event.ydata),round(event.xdata),radius))
        self.mask_changed()

    def mask_changed(self):
        self.revision+=1;self.dirty=True;self.update_buttons();self.draw()
        self.status.set(f'Mask có {len(self.actions)} vùng chọn + vùng đối xứng — bấm Xem trước.')

    def undo(self):
        if self.busy:return
        if self.actions:self.actions.pop();self.mask_changed()

    def clear_mask(self):
        if self.busy:return
        self.actions=[];self.mask_changed()

    def save(self):
        if self.result is None or self.dirty or self.busy:return
        path=filedialog.asksaveasfilename(parent=self.root,title='Lưu ảnh sau lọc',
          initialfile=f'{self.path.stem}_filtered.png',defaultextension='.png',
          filetypes=[('PNG','*.png'),('TIFF','*.tif'),('BMP','*.bmp')],confirmoverwrite=True)
        if not path:return
        try:save_image(path,self.result)
        except Exception as exc:messagebox.showerror('Không lưu được ảnh',str(exc),parent=self.root);return
        self.status.set(f'Đã lưu ảnh: {path}')

    def export(self):
        if self.result is None or self.dirty or self.busy:return
        directory=filedialog.askdirectory(parent=self.root,title='Chọn thư mục xuất bộ kết quả')
        if not directory:return
        names=['filtered.png','input.png','mask.png','spectrum.png','filtered_float.npy','mask.npy','spectrum_complex.npy','power_raw.npy','config.json']
        if any((Path(directory)/name).exists() for name in names):
            if not messagebox.askyesno('Ghi đè kết quả?', 'Thư mục đã có file kết quả trùng tên. Bạn có muốn ghi đè?',parent=self.root):return
        try:export_bundle(directory,self.result)
        except Exception as exc:messagebox.showerror('Không xuất được kết quả',str(exc),parent=self.root);return
        self.status.set(f'Đã xuất ảnh, phổ, mask và cấu hình: {directory}')

    def close(self):
        self.closed=True;self.root.destroy()


def main():
    try:root=tk.Tk()
    except tk.TclError as exc:
        raise SystemExit(f'Không mở được cửa sổ desktop: {exc}\nChạy lệnh trong terminal của phiên desktop có màn hình.')
    FilterApp(root);root.mainloop()


if __name__=='__main__':main()
